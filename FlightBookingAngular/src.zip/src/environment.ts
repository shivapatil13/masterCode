export const environment = {
    apiUrl: 'http://localhost:4000'
};