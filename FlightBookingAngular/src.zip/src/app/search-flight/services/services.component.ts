import { HttpClient } from '@angular/common/http';
import { Component, Injectable, OnInit } from '@angular/core';


@Injectable({
  providedIn: 'root'
})
export class ServicesComponent {
/*
    Add HttpClientModule in AppModule in import
    in your server, inject HttpClient

  */

    HOST:string = "http://localhost:3000/flights"

    constructor(private http:HttpClient) { }
  
    postFlight(flights){
      console.log(flights);
      return this.http.post(this.HOST, flights);
    }
  
    findAllFlight(){
      return this.http.get(this.HOST);
    }
  
    deleteFlights(id:number){
      return this.http.delete(this.HOST+"/"+id);
    }
  
    
  
  
}
