import { Component, OnInit } from '@angular/core';
import { ServicesComponent } from './services/services.component';

@Component({
  selector: 'app-search-flight',
  templateUrl: './search-flight.component.html',
  styleUrls: ['./search-flight.component.scss']
})
export class SearchFlightComponent implements OnInit {

  flights:any[] = [];

  constructor(private flightServices:ServicesComponent){}

  ngOnInit(){
    this.findFlights();
  }

  deleteFlight(id){
    this.flightServices.deleteFlights(id)
    .subscribe((res)=>{
      this.findFlights()
    })
  }

  createFlight(){
    let newFlight = {
      title: "Saerch Flight",
      date: "IndiGo",
      name: "",
      price: "1000/-",
      availability: "14",
      "id": 7
    } 

    this.flightServices.postFlight(newFlight)
    // .subscribe(function(){}.bind(this))
    .subscribe((res:any)=>{
      console.log(res);
      this.findFlights()
    })
  }



  findFlights(){
    this.flightServices.findAllFlight()
    .subscribe((res:any)=>{
      this.flights = res;
    })
  }


}
