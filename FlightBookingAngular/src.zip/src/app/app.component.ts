import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { Role, User } from './models';
import { AuthenticationService } from './services';

@Component({
  selector: 'app',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'CTSFlightBooking';
  currentUser: User;

  
  constructor(
      private router: Router,
      private authenticationService: AuthenticationService
  ) {
      this.authenticationService.currentUser.subscribe(x => this.currentUser = x);
  }

  get isAdmin() {
      return this.currentUser && this.currentUser.role === Role.Admin;
  }
  get isUser(){
    return this.currentUser && this.currentUser.role === Role.User;

  }

  logout() {
      this.authenticationService.logout();
      this.router.navigate(['/login']);
  }
}
