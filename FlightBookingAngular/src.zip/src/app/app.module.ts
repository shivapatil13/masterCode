import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { appRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { backendServiceProvider, ErrorInterceptor, BackendProvider, JwtInterceptor } from './helpers';
import { BookFlightComponent } from './book-flight/book-flight.component';
import { SearchFlightComponent } from './search-flight/search-flight.component';
import { BookingHistoryComponent } from './booking-history/booking-history.component';
import { ManageAirlinesComponent } from './manage-airlines/manage-airlines.component';
//import { ServicesComponent } from './search-flight/services/services.component';

//@ngModule wil identies the modules, components , and pipes and all making some of them public

@NgModule({
  imports: [
      BrowserModule,
      ReactiveFormsModule,
      HttpClientModule,
      appRoutingModule
  ],
  declarations: [
      AppComponent,
      HomeComponent,
      AdminComponent,
      LoginComponent,
      BookFlightComponent,
      SearchFlightComponent,
      BookingHistoryComponent,
      ManageAirlinesComponent,
      //ServicesComponent
     
      
  ],
  //provider for to fetch details from server dummy details
  providers: [
      { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
      { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },

      // provider used to create backend
      backendServiceProvider
  ],
  bootstrap: [AppComponent]
})

export class AppModule { }
