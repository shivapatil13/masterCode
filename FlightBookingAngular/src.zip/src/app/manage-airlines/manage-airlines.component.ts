import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-airlines',
  templateUrl: './manage-airlines.component.html',
  styleUrls: ['./manage-airlines.component.scss']
})
export class ManageAirlinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
