import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home';
import { AdminComponent } from './admin';
import { LoginComponent } from './login';
import { AuthGuard } from './helpers';
import { Role } from './models';
import { BookFlightComponent} from './book-flight';
import {SearchFlightComponent} from './search-flight';
import {BookingHistoryComponent} from './booking-history';
import {ManageAirlinesComponent} from './manage-airlines';


const routes: Routes = [
    {
        path: '',
        component: HomeComponent,
        canActivate: [AuthGuard]
    },
    {
        path: 'admin',
        component: AdminComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.Admin] }
    },
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path:'search-flight',
        component: SearchFlightComponent,
        canActivate: [AuthGuard],
        data: { roles: [Role.User] }

    },
    {
        path:'book-flight',
        component:BookFlightComponent ,
        canActivate: [AuthGuard],
        data: { roles: [Role.User] }

    },
    {
        path:'booking-history',
        component:BookingHistoryComponent ,
        canActivate: [AuthGuard],
        data: { roles: [Role.User] }

    },
    {
        path:'manage-airlines',
        component:ManageAirlinesComponent ,
        canActivate: [AuthGuard],
        data: { roles: [Role.User] }
    },
    

    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const appRoutingModule = RouterModule.forRoot(routes);