package com.flightapp.constant;

public class MailServicesConstant {
	public static final String LOG_MAIL_SERVICE_1 = "MailServices, sendMailContentBody() started execution..";
	public static final String LOG_MAIL_SERVICE_2 = "MailServices, sendMailContentBody() ended execution..";
	public static final String LOG_MAIL_SERVICE_3 = "Failed..! Got an issue while sending mail, please try again..";

	public static final String SEND_MAIL = "sendMailAcc";
	public static final String FILE_NAME = "AdminAccMailContentBody.txt";
}
