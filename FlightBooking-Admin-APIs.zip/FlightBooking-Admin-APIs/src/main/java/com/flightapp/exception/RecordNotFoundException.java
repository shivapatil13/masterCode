package com.flightapp.exception;

public class RecordNotFoundException extends RuntimeException {
	public RecordNotFoundException(String s) {
		super(s);
	}

}
